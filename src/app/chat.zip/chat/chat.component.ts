import { Component, OnInit } from '@angular/core';
import { NgForm, FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { ChatService } from './chat.service';
import { AuthService } from '../auth/auth.service';

@Component({
  selector: 'app-chat',
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.css']
})
export class ChatComponent implements OnInit {
  time;
  chatForm: FormGroup;
  listMsg = this.chatService.listMsg;
  status;
  uid;

  // textarea FormControl
  get textarea() { return this.chatForm.get('textarea'); }
  constructor(
    private fb: FormBuilder,
    private chatService: ChatService,
    private authService: AuthService
  ) { }

  ngOnInit() {

    // Creat Reactive Form
    this.chatForm = this.fb.group({
      textarea: new FormControl(null),
    });
    console.log('truong');
    this.chatService.getMsg();
    this.chatService.getMsgEvent.subscribe(() => {
      this.listMsg = this.chatService.listMsg;
    });

    // If textarea value is change, enforcement method isTying() in ChatService
    let timeout;
    this.textarea.valueChanges.subscribe(() => {
      this.chatService.isTyping('true', this.authService.account.uid);

      clearTimeout(timeout);
      timeout = setTimeout(() => {
        this.chatService.isTyping('false', this.authService.account.uid);
      }, 1000);
    });

    // Enforcement method getTyping() on ChatService to Check Typing to show isTyping if !== account
    this.chatService.getTyping();

    // Update status and uid when have event
    this.chatService.getMsgEvent.subscribe(() => {
      this.status = this.chatService.status;
      this.uid = this.chatService.uid;
    });

  }
  // End ngOnInit

  // Send content chat and enforcement method onSend() in ChatService
  onSend(msg) { // msg is content of textarea
    this.time = new Date();
    this.chatService.onSend({
      msg: msg,
      email: this.authService.account.email,
      time: this.time.toLocaleString()
    });
    this.chatForm.reset();
  }

}
